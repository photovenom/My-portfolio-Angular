import { Component, HostBinding, OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';

@Component({
  selector: 'app-baner',
  standalone: true,
  imports: [],
  templateUrl: './baner.component.html',
  styleUrl: './baner.component.css'
})
export class BanerComponent implements OnInit {
  constructor() {}
  @HostBinding('class.pc') pcMode = false;
  ngOnInit(): void {}
}
