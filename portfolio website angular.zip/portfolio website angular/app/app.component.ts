import { Component, ElementRef, HostBinding } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { BanerComponent } from './baner/baner.component';
import { ContactComponent } from './contact/contact.component';
import { EducationComponent } from './education/education.component';
import { PersonalComponent } from './personal-information/personal-information.component';
import { SkillsComponent } from './skills/skills.component';
import { ProjectsComponent } from './projects/projects.component';
import { WorkExperienceComponent } from './work-experience/work-experience.component';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';


@Component({
  selector: 'app-root',
  standalone: true,
  imports:[BanerComponent, ContactComponent,EducationComponent, PersonalComponent,
    WorkExperienceComponent, SkillsComponent, ProjectsComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'portfolio';
  @HostBinding('class.pc') pcMode = false;
  constructor(private element: ElementRef,private breakpointObserver: BreakpointObserver) {
    this.breakpointObserver
      .observe([Breakpoints.HandsetPortrait, Breakpoints.WebLandscape])
      .subscribe({
        next: (result: any) => {
          for (let breakpoint of Object.keys(result.breakpoints))
            if (result.breakpoints[breakpoint]) {
              if (breakpoint === Breakpoints.HandsetPortrait)
                this.element.nativeElement.classList.remove('pc');

              if (breakpoint === Breakpoints.WebLandscape)
                this.element.nativeElement.classList.add('pc');
            }
        },
      });
  }
}
