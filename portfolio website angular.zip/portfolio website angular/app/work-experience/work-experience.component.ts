import { Component, OnInit } from '@angular/core';
import { WorkExperience } from '../models/models';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-work-experience',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './work-experience.component.html',
  styleUrls: ['./work-experience.component.css'],
})
export class WorkExperienceComponent implements OnInit {
  workExpList: WorkExperience[] = [
    {
      role: 'Web Developer Intern',
      company: 'Elite Softwares, Pune',
      duration: 'jan 2024 - march 2024',
      description: [
        'This training contained frontend technologies like HTML, CSS, Bootstrap',
        'Backend technology - python framework, Django',
        
      ],
    },
  ];
  constructor() {}

  ngOnInit(): void {}
}
