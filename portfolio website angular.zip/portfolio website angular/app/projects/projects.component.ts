import { Component, OnInit } from '@angular/core';
import { Project } from '../models/models';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-projects',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css'],
})
export class ProjectsComponent implements OnInit {
  projects: Project[] = [
    {
      title: ' Personal Portfolio website using Angular Framework',
      technologies: 'Angular, HTML5, CSS3.',
      description: [
        ' Developed a dynamic and responsive personal portfolio website.',
        ' This project include technologies: Angular, HTML5, CSS3, Typescript.',
      ],
    },
    {
      title: 'Blog Application using Python-Django',
      technologies: ' Django, HTML5, CSS3, MySQL',
      description: [
        'Developed a simple blog platform where users can create, edit, and delete blog posts. ',
        'This project include technologies: Django, HTML5, CSS3, MySQL.',
      ],
    },
    {
      title: 'To-Do List Application using Python',
      technologies: 'Python',
      description: [
        ' Developed a to-do list application where users can add, edit, delete, and mark tasks as completed.',
      ],
    },
  ];
  constructor() {}

  ngOnInit(): void {}
}
