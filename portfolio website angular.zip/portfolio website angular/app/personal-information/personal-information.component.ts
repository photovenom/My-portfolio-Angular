import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-personal-information',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './personal-information.component.html',
  styleUrls: ['./personal-information.component.css'] 
})
export class PersonalComponent implements OnInit { 

  myData: string[][] = [
    ['Name', 'Vishal Auti'],
    ['DOB', '09/11/2002'],
    ['Age', '22 Years'],
    ['Education', 'B.E.(2024)'],
    ['Interests', 'Cricket | Photography | Philosophy'],
  ];

  aboutMe: string[] = [
    'Hi, I am a Angular developer seeking for opportunity in software industry.',
    'Completed my Bachelors degree in Information Technology, from SPPU University.',
    'Along with degree I have learned different technologies. Always eager to learn.',
    'Currently, seeking for a job.',
  ];

  constructor() {}
  ngOnInit(): void {}

}
