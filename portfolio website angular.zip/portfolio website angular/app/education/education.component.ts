import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Education } from '../models/models';

@Component({
  selector: 'app-education',
  standalone: true,
  imports: [CommonModule], 
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css'] 
})
export class EducationComponent implements OnInit {
  educationList: Education[] = [
    {
      institute: "Savitribai Phule Pune University",
      course: 'B.E. Information Technology',
      duration: '2020-2024',
      score: '85%',
    },
    {
      institute: 'Abasaheb Kakade Jr. College, Shevgaon',
      course: 'HSC',
      duration: '2019-20',
      score: '69%',
    },
    {
      institute: 'Abasaheb Kakade vidyalaya, Shevgaon',
      course: 'SSC',
      duration: '2017-18',
      score: '85%',
    },
  ];

  constructor() {}
  ngOnInit(): void {}
}
